export default function SuccessPage(){
  return (
    <div className="card">
      <h2 className="text-xl font-bold mb-2">Thank you!</h2>
      <p className="text-gray-700">Your order has been received. A confirmation email is on its way.</p>
    </div>
  );
}
